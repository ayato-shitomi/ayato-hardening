rm -rf apache.sh ports.conf user.sh vsftpd-2.3.4-infected vsftpd.sh webapp.sh ../.bash_history ../h.zip
