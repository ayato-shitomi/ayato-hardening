# Dev memo

If you want to connect with SSH, use the following credentials:

```
dev
devpass123
```
